# Light Up Box 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Emely-P-rez/pen/WNqgYNx](https://codepen.io/Emely-P-rez/pen/WNqgYNx).

Hover your mouse over the text 